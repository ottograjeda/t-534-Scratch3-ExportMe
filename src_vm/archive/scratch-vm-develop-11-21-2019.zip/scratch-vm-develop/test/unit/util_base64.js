const test = require('tap').test;
// const Base64Util = require('../../src/util/base64-util');

test('base64ToUint8Array', t => {
    t.end();
});

test('uint8ArrayToBase64', t => {
    t.end();
});
