const test = require('tap').test;
// const MicroBit = require('../../src/extensions/scratch3_microbit/index.js');

test('displayText', t => {
    t.end();
});

test('displayMatrix', t => {
    t.end();
});

// etc...
