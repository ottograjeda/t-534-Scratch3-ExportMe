const test = require('tap').test;
// const ScratchBLE = require('../../src/io/scratchBLE');

test('constructor', t => {
    t.end();
});

test('waitForSocket', t => {
    t.end();
});

test('requestPeripheral', t => {
    t.end();
});

test('didReceiveCall', t => {
    t.end();
});

test('read', t => {
    t.end();
});

test('write', t => {
    t.end();
});
